package com.kotlinspring

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CourseCatalogServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
