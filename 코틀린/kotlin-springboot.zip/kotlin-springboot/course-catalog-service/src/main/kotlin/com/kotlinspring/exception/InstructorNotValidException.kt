package com.kotlinspring.exception

class InstructorNotValidException(message: String) : RuntimeException(message) {

}
