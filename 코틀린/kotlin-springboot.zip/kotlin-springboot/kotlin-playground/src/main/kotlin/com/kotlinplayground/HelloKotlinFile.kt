package com.kotlinplayground

fun abc(){
    println("abc")
}

fun main() {
    println("Hello Kotlin")
    abc()
}