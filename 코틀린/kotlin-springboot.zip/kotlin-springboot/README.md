# kotlin-spring
This project holds the course code for kotlin and spring

## H2 Database

- Access the h2 database in the following link - http://localhost:8080/h2-console
